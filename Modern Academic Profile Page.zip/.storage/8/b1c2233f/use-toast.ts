// Importing from our UI components, which already has the implementation
export { useToast } from "@/components/ui/use-toast";