import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ResearchArea {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
}

export function ResearchSection() {
  const researchAreas: ResearchArea[] = [
    {
      id: 1,
      title: "Machine Learning",
      description: "Developing novel machine learning algorithms with applications in healthcare and natural language processing.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-brain-circuit">
          <path d="M12 4.5a2.5 2.5 0 0 0-4.96-.46 2.5 2.5 0 0 0-1.98 3 2.5 2.5 0 0 0-1.32 4.24 3 3 0 0 0 .34 5.58 2.5 2.5 0 0 0 2.96 3.08A2.5 2.5 0 0 0 9.5 22c1.21 0 2.5-.74 2.5-2.5m0-15a2.5 2.5 0 0 1 4.96-.46 2.5 2.5 0 0 1 1.98 3 2.5 2.5 0 0 1 1.32 4.24 3 3 0 0 1-.34 5.58 2.5 2.5 0 0 1-2.96 3.08A2.5 2.5 0 0 1 14.5 22c-1.21 0-2.5-.74-2.5-2.5m0-15V5m0 14.5V19"/>
          <circle cx="12" cy="12" r="2"/>
          <path d="M12 9v1"/>
          <path d="M12 14v1"/>
          <path d="m14.6 10.5-.87.5"/>
          <path d="m10.27 13-.87.5"/>
          <path d="m14.6 13.5-.87-.5"/>
          <path d="m10.27 11-.87-.5"/>
        </svg>
      )
    },
    {
      id: 2,
      title: "Computational Neuroscience",
      description: "Investigating brain functions through computational models to understand cognitive processes and neural networks.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-brain">
          <path d="M9.5 2a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/>
          <path d="M6.5 6.5a2.5 2.5 0 1 0 3.5 3.5"/>
          <path d="M14.5 2a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z"/>
          <path d="M17.5 6.5a2.5 2.5 0 1 1-3.5 3.5"/>
          <path d="M14.5 17a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z"/>
          <path d="M17.5 17.5a2.5 2.5 0 1 1-3.5-3.5"/>
          <path d="M9.5 17a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/>
          <path d="M6.5 17.5a2.5 2.5 0 1 0 3.5-3.5"/>
          <path d="M12 7v10"/>
          <path d="M8 12h8"/>
        </svg>
      )
    },
    {
      id: 3,
      title: "AI Ethics & Governance",
      description: "Exploring ethical implications and developing governance frameworks for responsible AI development and deployment.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-scale-3d">
          <path d="M5 7v12h12"/>
          <path d="m5 19 6-6"/>
          <rect width="4" height="4" x="3" y="3" rx="1"/>
          <rect width="4" height="4" x="17" y="3" rx="1"/>
          <rect width="4" height="4" x="17" y="17" rx="1"/>
        </svg>
      )
    },
    {
      id: 4,
      title: "Human-Computer Interaction",
      description: "Designing intuitive interfaces and interaction paradigms that enhance the user experience with AI systems.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-monitor-smartphone">
          <path d="M18 8V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8"/>
          <path d="M10 19v-3.96 3.15"/>
          <path d="M7 19h5"/>
          <rect width="6" height="10" x="16" y="12" rx="2"/>
        </svg>
      )
    }
  ];

  return (
    <section id="research" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Research Areas</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            My research spans multiple disciplines, focusing on developing innovative solutions to complex computational challenges.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {researchAreas.map((area) => (
            <Card key={area.id} className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <div className="text-primary mb-4">
                  {area.icon}
                </div>
                <CardTitle>{area.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  {area.description}
                </CardDescription>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" size="sm" className="mt-2">
                  Read More
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <Button variant="outline">View All Research Projects</Button>
        </div>
      </div>
    </section>
  );
}