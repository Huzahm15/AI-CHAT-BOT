import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Publication {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  field: string;
  abstract: string;
  doi: string;
  pdfUrl: string | null;
}

export function PublicationsSection() {
  const [open, setOpen] = useState(false);
  const [selectedPub, setSelectedPub] = useState<Publication | null>(null);
  const [yearFilter, setYearFilter] = useState<string>("all");
  const [fieldFilter, setFieldFilter] = useState<string>("all");

  const publications: Publication[] = [
    {
      id: "pub1",
      title: "Deep Learning Approaches for Neural Network Optimization",
      authors: "Doe, J., Smith, A., Johnson, B.",
      journal: "Journal of Artificial Intelligence Research",
      year: 2023,
      field: "Machine Learning",
      abstract: "This paper presents novel deep learning approaches for optimizing neural networks. We introduce a framework that significantly reduces computational overhead while maintaining high accuracy. Our experiments show a 35% improvement over state-of-the-art methods across multiple benchmark datasets.",
      doi: "10.1000/xyz123",
      pdfUrl: "/papers/deep-learning-approaches.pdf"
    },
    {
      id: "pub2",
      title: "Cognitive Models of Decision Making in Human-AI Interaction",
      authors: "Doe, J., Williams, C., Brown, D.",
      journal: "Cognitive Science Journal",
      year: 2023,
      field: "Computational Neuroscience",
      abstract: "We investigate how humans make decisions when interacting with AI systems. This study combines computational models with empirical data to create a framework for understanding decision-making processes in human-AI collaborative environments.",
      doi: "10.1000/abc456",
      pdfUrl: null
    },
    {
      id: "pub3",
      title: "Ethical Frameworks for Autonomous Systems",
      authors: "Doe, J., Garcia, E.",
      journal: "AI & Ethics",
      year: 2022,
      field: "AI Ethics & Governance",
      abstract: "This paper proposes a comprehensive ethical framework for the development and deployment of autonomous systems. We analyze current governance approaches and suggest policy recommendations that balance innovation with ethical considerations.",
      doi: "10.1000/def789",
      pdfUrl: "/papers/ethical-frameworks.pdf"
    },
    {
      id: "pub4",
      title: "Interface Design Principles for Explainable AI",
      authors: "Doe, J., Miller, F., Wilson, G.",
      journal: "Human-Computer Interaction Review",
      year: 2022,
      field: "Human-Computer Interaction",
      abstract: "We present design principles for creating interfaces that effectively communicate AI decision-making processes to non-expert users. Our user studies demonstrate improved trust and understanding when these principles are applied to explanatory interfaces.",
      doi: "10.1000/ghi012",
      pdfUrl: "/papers/interface-design.pdf"
    },
    {
      id: "pub5",
      title: "Neural Correlates of Learning in Artificial Networks",
      authors: "Doe, J., Taylor, H.",
      journal: "Computational Neuroscience Today",
      year: 2021,
      field: "Computational Neuroscience",
      abstract: "This study draws parallels between learning mechanisms in biological neural networks and artificial neural networks. We identify key similarities and differences that could inform more brain-inspired computing architectures.",
      doi: "10.1000/jkl345",
      pdfUrl: "/papers/neural-correlates.pdf"
    },
    {
      id: "pub6",
      title: "Reinforcement Learning for Adaptive User Interfaces",
      authors: "Doe, J., Lee, I., Rodriguez, J.",
      journal: "ACM Transactions on Interactive Systems",
      year: 2021,
      field: "Machine Learning",
      abstract: "We present a reinforcement learning approach that enables user interfaces to adapt to individual user behavior patterns over time. Our method shows significant improvements in user efficiency and satisfaction compared to static interfaces.",
      doi: "10.1000/mno678",
      pdfUrl: null
    }
  ];

  // Get unique years and fields for filtering
  const years = [...new Set(publications.map(pub => pub.year))].sort((a, b) => b - a);
  const fields = [...new Set(publications.map(pub => pub.field))];

  // Filter publications based on selected filters
  const filteredPubs = publications.filter(pub => {
    const yearMatch = yearFilter === "all" || pub.year.toString() === yearFilter;
    const fieldMatch = fieldFilter === "all" || pub.field === fieldFilter;
    return yearMatch && fieldMatch;
  });

  const handlePubClick = (pub: Publication) => {
    setSelectedPub(pub);
    setOpen(true);
  };

  return (
    <section id="publications" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Publications</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Browse through my recent academic publications and research papers.
          </p>
        </div>

        <div className="mb-8 flex flex-col md:flex-row gap-4 justify-center">
          <div className="w-full md:w-48">
            <Select value={yearFilter} onValueChange={setYearFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Years</SelectItem>
                {years.map(year => (
                  <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="w-full md:w-48">
            <Select value={fieldFilter} onValueChange={setFieldFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by field" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Fields</SelectItem>
                {fields.map(field => (
                  <SelectItem key={field} value={field}>{field}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="list" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="grid">Grid View</TabsTrigger>
          </TabsList>

          <TabsContent value="list" className="mt-6">
            <div className="space-y-4">
              {filteredPubs.map((pub) => (
                <div 
                  key={pub.id} 
                  className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                  onClick={() => handlePubClick(pub)}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                    <div>
                      <h3 className="font-medium text-lg">{pub.title}</h3>
                      <p className="text-muted-foreground text-sm">{pub.authors}</p>
                      <p className="text-sm">{pub.journal}, {pub.year}</p>
                    </div>
                    <div className="flex items-center gap-2 self-start">
                      <Badge variant="outline">{pub.field}</Badge>
                      {pub.pdfUrl && (
                        <Badge>PDF</Badge>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="grid" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredPubs.map((pub) => (
                <div 
                  key={pub.id} 
                  className="p-4 border rounded-lg hover:shadow-md cursor-pointer transition-all h-full flex flex-col"
                  onClick={() => handlePubClick(pub)}
                >
                  <h3 className="font-medium text-lg mb-2">{pub.title}</h3>
                  <p className="text-muted-foreground text-sm mb-1">{pub.authors}</p>
                  <p className="text-sm mb-3">{pub.journal}, {pub.year}</p>
                  <div className="mt-auto flex flex-wrap gap-2">
                    <Badge variant="outline">{pub.field}</Badge>
                    {pub.pdfUrl && (
                      <Badge>PDF</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {filteredPubs.length === 0 && (
          <div className="text-center py-10">
            <p className="text-muted-foreground">No publications match your filter criteria.</p>
          </div>
        )}

        <Dialog open={open} onOpenChange={setOpen}>
          {selectedPub && (
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>{selectedPub.title}</DialogTitle>
                <div className="flex flex-wrap gap-2 mt-2">
                  <Badge variant="outline">{selectedPub.field}</Badge>
                  <Badge variant="outline">{selectedPub.year}</Badge>
                </div>
              </DialogHeader>
              <div className="mt-4">
                <p className="font-medium">Authors</p>
                <p className="text-muted-foreground mb-4">{selectedPub.authors}</p>
                
                <p className="font-medium">Journal</p>
                <p className="text-muted-foreground mb-4">{selectedPub.journal}</p>
                
                <p className="font-medium">Abstract</p>
                <p className="text-muted-foreground mb-4">{selectedPub.abstract}</p>
                
                <p className="font-medium">DOI</p>
                <p className="text-muted-foreground mb-6">{selectedPub.doi}</p>
                
                <div className="flex gap-4">
                  {selectedPub.pdfUrl ? (
                    <Button asChild>
                      <a href={selectedPub.pdfUrl} target="_blank" rel="noopener noreferrer">
                        View PDF
                      </a>
                    </Button>
                  ) : (
                    <Button disabled>PDF Not Available</Button>
                  )}
                  <Button variant="outline" asChild>
                    <a href={`https://doi.org/${selectedPub.doi}`} target="_blank" rel="noopener noreferrer">
                      View Online
                    </a>
                  </Button>
                </div>
              </div>
            </DialogContent>
          )}
        </Dialog>
      </div>
    </section>
  );
}