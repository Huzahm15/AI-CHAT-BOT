import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section 
      id="home" 
      className="relative min-h-[90vh] flex items-center"
      style={{
        backgroundImage: "linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url('/assets/university-campus.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center"
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black opacity-50"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
            Prof. John Doe
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-6">
            Computer Science & Artificial Intelligence
          </p>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl">
            Leading research in machine learning and computational neuroscience with over 20 years of experience pioneering innovative solutions to complex AI challenges.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button asChild size="lg">
              <a href="#research">View Research</a>
            </Button>
            <Button asChild variant="outline" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20" size="lg">
              <a href="#contact">Contact Me</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}