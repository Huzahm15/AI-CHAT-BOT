import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { HeroSection } from "@/components/sections/hero";
import { ResearchSection } from "@/components/sections/research";
import { PublicationsSection } from "@/components/sections/publications";
import { CVSection } from "@/components/sections/cv";
import { TestimonialsSection } from "@/components/sections/testimonials";
import { ContactSection } from "@/components/sections/contact";
import { ChatBotSection } from "@/components/sections/chat-bot";
import { Toaster } from "@/components/ui/toaster";

export default function AcademicProfile() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <HeroSection />
        <ResearchSection />
        <PublicationsSection />
        <CVSection />
        <TestimonialsSection />
        <ChatBotSection />
        <ContactSection />
      </main>
      <Footer />
      <Toaster />
    </div>
  );
}