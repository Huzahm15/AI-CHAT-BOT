import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

// Research data from the professor's profile
const researchData = [
  {
    id: 1,
    title: "Machine Learning",
    content: "Developing novel machine learning algorithms with applications in healthcare and natural language processing.",
    keywords: ["deep learning", "neural networks", "nlp", "healthcare", "algorithms"]
  },
  {
    id: 2,
    title: "Computational Neuroscience",
    content: "Investigating brain functions through computational models to understand cognitive processes and neural networks.",
    keywords: ["brain", "neural", "cognitive", "computational models", "brain functions"]
  },
  {
    id: 3,
    title: "AI Ethics & Governance",
    content: "Exploring ethical implications and developing governance frameworks for responsible AI development and deployment.",
    keywords: ["ethics", "governance", "responsible AI", "policy", "regulations"]
  },
  {
    id: 4,
    title: "Human-Computer Interaction",
    content: "Designing intuitive interfaces and interaction paradigms that enhance the user experience with AI systems.",
    keywords: ["interfaces", "user experience", "interaction", "design", "usability"]
  }
];

// Publications data from the professor's profile
const publicationsData = [
  {
    id: "pub1",
    title: "Deep Learning Approaches for Neural Network Optimization",
    authors: "Doe, J., Smith, A., Johnson, B.",
    journal: "Journal of Artificial Intelligence Research",
    year: 2023,
    field: "Machine Learning",
    abstract: "This paper presents novel deep learning approaches for optimizing neural networks. We introduce a framework that significantly reduces computational overhead while maintaining high accuracy. Our experiments show a 35% improvement over state-of-the-art methods across multiple benchmark datasets.",
    keywords: ["deep learning", "neural networks", "optimization", "computational efficiency"]
  },
  {
    id: "pub2",
    title: "Cognitive Models of Decision Making in Human-AI Interaction",
    authors: "Doe, J., Williams, C., Brown, D.",
    journal: "Cognitive Science Journal",
    year: 2023,
    field: "Computational Neuroscience",
    abstract: "We investigate how humans make decisions when interacting with AI systems. This study combines computational models with empirical data to create a framework for understanding decision-making processes in human-AI collaborative environments.",
    keywords: ["cognitive models", "decision making", "human-ai interaction", "collaboration"]
  },
  {
    id: "pub3",
    title: "Ethical Frameworks for Autonomous Systems",
    authors: "Doe, J., Garcia, E.",
    journal: "AI & Ethics",
    year: 2022,
    field: "AI Ethics & Governance",
    abstract: "This paper proposes a comprehensive ethical framework for the development and deployment of autonomous systems. We analyze current governance approaches and suggest policy recommendations that balance innovation with ethical considerations.",
    keywords: ["ethics", "autonomous systems", "governance", "policy", "ai ethics"]
  },
  {
    id: "pub4",
    title: "Interface Design Principles for Explainable AI",
    authors: "Doe, J., Miller, F., Wilson, G.",
    journal: "Human-Computer Interaction Review",
    year: 2022,
    field: "Human-Computer Interaction",
    abstract: "We present design principles for creating interfaces that effectively communicate AI decision-making processes to non-expert users. Our user studies demonstrate improved trust and understanding when these principles are applied to explanatory interfaces.",
    keywords: ["interface design", "explainable ai", "user trust", "transparency"]
  },
  {
    id: "pub5",
    title: "Neural Correlates of Learning in Artificial Networks",
    authors: "Doe, J., Taylor, H.",
    journal: "Computational Neuroscience Today",
    year: 2021,
    field: "Computational Neuroscience",
    abstract: "This study draws parallels between learning mechanisms in biological neural networks and artificial neural networks. We identify key similarities and differences that could inform more brain-inspired computing architectures.",
    keywords: ["neural correlates", "learning", "artificial networks", "brain-inspired computing"]
  },
  {
    id: "pub6",
    title: "Reinforcement Learning for Adaptive User Interfaces",
    authors: "Doe, J., Lee, I., Rodriguez, J.",
    journal: "ACM Transactions on Interactive Systems",
    year: 2021,
    field: "Machine Learning",
    abstract: "We present a reinforcement learning approach that enables user interfaces to adapt to individual user behavior patterns over time. Our method shows significant improvements in user efficiency and satisfaction compared to static interfaces.",
    keywords: ["reinforcement learning", "adaptive interfaces", "user behavior", "personalization"]
  }
];

type Message = {
  role: "user" | "assistant";
  content: string;
  citations?: Array<{
    type: "research" | "publication";
    id: string | number;
    title: string;
  }>;
};

export function ChatBotSection() {
  const { toast } = useToast();
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm Prof. John Doe's research assistant AI. How can I help you learn about the professor's work in machine learning, computational neuroscience, AI ethics, or human-computer interaction?"
    }
  ]);
  
  // Function to find relevant research and publications based on user query
  const findRelevantContent = (query: string) => {
    const lowerQuery = query.toLowerCase();
    const queryWords = lowerQuery.split(/\s+/).filter(word => word.length > 2);
    
    // Score each research area and publication based on keyword matches
    const scoredResearch = researchData.map(research => {
      let score = 0;
      
      // Check title match
      if (research.title.toLowerCase().includes(lowerQuery)) score += 10;
      
      // Check content match
      if (research.content.toLowerCase().includes(lowerQuery)) score += 5;
      
      // Check individual keyword matches
      queryWords.forEach(word => {
        if (research.title.toLowerCase().includes(word)) score += 3;
        if (research.content.toLowerCase().includes(word)) score += 2;
        research.keywords.forEach(keyword => {
          if (keyword.includes(word)) score += 4;
        });
      });
      
      return { ...research, score };
    });
    
    const scoredPublications = publicationsData.map(pub => {
      let score = 0;
      
      // Check title match
      if (pub.title.toLowerCase().includes(lowerQuery)) score += 10;
      
      // Check abstract match
      if (pub.abstract.toLowerCase().includes(lowerQuery)) score += 8;
      
      // Check field match
      if (pub.field.toLowerCase().includes(lowerQuery)) score += 6;
      
      // Check individual keyword matches
      queryWords.forEach(word => {
        if (pub.title.toLowerCase().includes(word)) score += 3;
        if (pub.abstract.toLowerCase().includes(word)) score += 2;
        if (pub.field.toLowerCase().includes(word)) score += 2;
        pub.keywords.forEach(keyword => {
          if (keyword.includes(word)) score += 4;
        });
      });
      
      return { ...pub, score };
    });
    
    // Filter items with a score above threshold and sort by score
    const relevantResearch = scoredResearch.filter(item => item.score > 5).sort((a, b) => b.score - a.score);
    const relevantPublications = scoredPublications.filter(item => item.score > 5).sort((a, b) => b.score - a.score);
    
    return { relevantResearch, relevantPublications };
  };

  // Generate a response based on matched research and publications
  const generateResponse = (query: string) => {
    const { relevantResearch, relevantPublications } = findRelevantContent(query);
    
    // If no relevant information found
    if (relevantResearch.length === 0 && relevantPublications.length === 0) {
      return {
        content: "I don't have specific information about that in my knowledge base. You might want to ask about the professor's work in machine learning, computational neuroscience, AI ethics, or human-computer interaction.",
        citations: []
      };
    }
    
    let response = "";
    const citations: Message["citations"] = [];
    
    // Generate response based on research areas
    if (relevantResearch.length > 0) {
      response += "Based on Professor Doe's research:\n\n";
      
      relevantResearch.slice(0, 2).forEach(research => {
        response += `**${research.title}**: ${research.content}\n\n`;
        citations.push({
          type: "research",
          id: research.id,
          title: research.title
        });
      });
    }
    
    // Add information from publications if available
    if (relevantPublications.length > 0) {
      if (response) response += "Related publications:\n\n";
      else response += "I found these relevant publications by Professor Doe:\n\n";
      
      relevantPublications.slice(0, 2).forEach(pub => {
        response += `**${pub.title}** (${pub.year}): ${pub.abstract.substring(0, 150)}...\n\nPublished in *${pub.journal}*\n\n`;
        citations.push({
          type: "publication",
          id: pub.id,
          title: pub.title
        });
      });
    }
    
    // Add a follow-up suggestion
    const suggestedTopics = Array.from(new Set([
      ...relevantResearch.map(r => r.title),
      ...relevantPublications.map(p => p.field)
    ])).slice(0, 2);
    
    if (suggestedTopics.length > 0) {
      response += "You might also be interested in asking more about " + 
        suggestedTopics.join(" or ") + ".";
    }
    
    return { content: response, citations };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage: Message = {
      role: "user",
      content: input
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsProcessing(true);
    
    try {
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const { content, citations } = generateResponse(input);
      
      const assistantMessage: Message = {
        role: "assistant",
        content,
        citations
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error processing request:", error);
      toast({
        title: "Error",
        description: "Failed to process your request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <section id="chat-bot" className="py-16 bg-slate-50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center mb-10 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">Ask the Research Assistant</h2>
          <p className="max-w-[700px] text-gray-500 md:text-xl">
            Have questions about Professor Doe's research? Our AI assistant can help you find answers from the professor's publications and research areas.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Research Assistant AI</span>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setMessages([{
                    role: "assistant",
                    content: "Hello! I'm Prof. John Doe's research assistant AI. How can I help you learn about the professor's work in machine learning, computational neuroscience, AI ethics, or human-computer interaction?"
                  }])}
                >
                  Clear Chat
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] pr-4">
                <div className="flex flex-col gap-4">
                  {messages.map((message, index) => (
                    <div 
                      key={index} 
                      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div 
                        className={`max-w-[80%] p-4 rounded-lg ${
                          message.role === 'user' 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted'
                        }`}
                      >
                        <div className="whitespace-pre-line">
                          {message.content.split("**").map((part, i) => 
                            i % 2 === 0 ? 
                              part : 
                              <strong key={i}>{part}</strong>
                          )}
                        </div>
                        
                        {message.citations && message.citations.length > 0 && (
                          <div className="mt-3 pt-2 border-t border-gray-200 dark:border-gray-700">
                            <p className="text-xs text-gray-500 mb-1">Sources:</p>
                            <div className="flex flex-wrap gap-1">
                              {message.citations.map((citation, i) => (
                                <Badge 
                                  key={i} 
                                  variant="outline" 
                                  className="text-xs"
                                >
                                  {citation.type === 'research' ? '📚' : '📄'} {citation.title}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  {isProcessing && (
                    <div className="flex justify-start">
                      <div className="max-w-[80%] p-4 rounded-lg bg-muted">
                        <div className="flex gap-1 items-center">
                          <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
                          <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-75"></div>
                          <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-150"></div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>
              
              <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
                <Input 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about the professor's research..."
                  disabled={isProcessing}
                  className="flex-1"
                />
                <Button type="submit" disabled={isProcessing || !input.trim()}>
                  Send
                </Button>
              </form>
            </CardContent>
          </Card>
          
          <div className="mt-4 text-center text-sm text-gray-500">
            <p>Try asking about: "machine learning applications", "neural network optimization", "ethical frameworks for AI", or "interface design principles"</p>
          </div>
        </div>
      </div>
    </section>
  );
}