// Re-export from the original implementation
export { useToast, toast } from "@/components/ui/use-toast";