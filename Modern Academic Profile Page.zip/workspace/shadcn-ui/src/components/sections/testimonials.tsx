import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { cn } from "@/lib/utils";

interface Testimonial {
  id: number;
  quote: string;
  name: string;
  role: string;
  institution: string;
  avatarUrl?: string;
  initials: string;
}

export function TestimonialsSection() {
  const testimonials: Testimonial[] = [
    {
      id: 1,
      quote: "Professor Doe's research on machine learning algorithms has revolutionized how we approach healthcare data analytics. His work has directly influenced our department's research direction.",
      name: "Dr. Sarah Johnson",
      role: "Department Chair",
      institution: "Stanford University",
      avatarUrl: "/assets/avatars/avatar-1.jpg",
      initials: "SJ"
    },
    {
      id: 2,
      quote: "Working with John on the AI Ethics Committee has been an enlightening experience. His balanced approach to technology governance ensures innovation while respecting human values.",
      name: "Prof. Michael Chen",
      role: "AI Ethics Researcher",
      institution: "MIT",
      avatarUrl: "/assets/avatars/avatar-2.jpg",
      initials: "MC"
    },
    {
      id: 3,
      quote: "As a former PhD student under Professor Doe's supervision, I benefited immensely from his mentorship. His guidance shaped not only my research but my entire academic career.",
      name: "Dr. Emily Rodriguez",
      role: "Assistant Professor",
      institution: "University of California",
      avatarUrl: "/assets/avatars/avatar-3.jpg",
      initials: "ER"
    },
    {
      id: 4,
      quote: "Professor Doe's collaborative approach to research has created valuable bridges between our industry labs and academic institutions, resulting in breakthroughs we couldn't have achieved alone.",
      name: "Dr. James Wilson",
      role: "Research Director",
      institution: "Google AI",
      avatarUrl: "/assets/avatars/avatar-4.jpg",
      initials: "JW"
    },
    {
      id: 5,
      quote: "The computational neuroscience framework developed by John has provided us with new insights into neural processes that we're now applying in our clinical research.",
      name: "Dr. Lisa Thompson",
      role: "Neuroscientist",
      institution: "National Institute of Health",
      avatarUrl: "/assets/avatars/avatar-5.jpg",
      initials: "LT"
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Colleague Testimonials</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Insights from colleagues and former students about collaboration and impact.
          </p>
        </div>

        <div className="mt-10">
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent className="py-4">
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={testimonial.id} className="sm:basis-1/2 lg:basis-1/3 pl-4">
                  <div className="p-1">
                    <Card className={cn(
                      "h-full bg-gradient-to-br p-0.5",
                      index % 3 === 0 ? "from-blue-50 to-blue-100" :
                      index % 3 === 1 ? "from-indigo-50 to-indigo-100" :
                      "from-purple-50 to-purple-100"
                    )}>
                      <CardContent className="bg-white rounded-[inherit] p-6 h-full flex flex-col">
                        <div className="flex-1">
                          <p className="text-muted-foreground italic mb-4">"{testimonial.quote}"</p>
                        </div>
                        <div className="flex items-center mt-4">
                          <Avatar className="h-10 w-10 mr-4">
                            {testimonial.avatarUrl && <AvatarImage src={testimonial.avatarUrl} alt={testimonial.name} />}
                            <AvatarFallback>{testimonial.initials}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{testimonial.name}</p>
                            <p className="text-xs text-muted-foreground">{testimonial.role}, {testimonial.institution}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <div className="flex justify-center mt-6 gap-2">
              <CarouselPrevious className="static transform-none" />
              <CarouselNext className="static transform-none" />
            </div>
          </Carousel>
        </div>
      </div>
    </section>
  );
}