import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function CVSection() {
  return (
    <section id="cv" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Curriculum Vitae</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            My academic background, professional experience, and achievements.
          </p>
        </div>

        <div className="flex justify-center mb-8">
          <Button size="lg" className="flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-download">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" x2="12" y1="15" y2="3"/>
            </svg>
            Download Full CV
          </Button>
        </div>

        <Tabs defaultValue="education" className="w-full">
          <TabsList className="grid max-w-2xl mx-auto grid-cols-4">
            <TabsTrigger value="education">Education</TabsTrigger>
            <TabsTrigger value="experience">Experience</TabsTrigger>
            <TabsTrigger value="awards">Awards</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
          </TabsList>
          
          <div className="mt-8">
            <TabsContent value="education" className="space-y-4">
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">Ph.D. in Computer Science</h3>
                  <p className="text-muted-foreground">Stanford University | 2005 - 2009</p>
                </CardHeader>
                <CardContent className="pt-6">
                  <p>Dissertation: "Neural Network Optimization for Large-Scale Machine Learning Applications"</p>
                  <p className="mt-2">Advisor: Prof. James Williams</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">M.S. in Computer Science</h3>
                  <p className="text-muted-foreground">Massachusetts Institute of Technology | 2003 - 2005</p>
                </CardHeader>
                <CardContent className="pt-6">
                  <p>Focus: Artificial Intelligence and Machine Learning</p>
                  <p className="mt-2">Thesis: "Reinforcement Learning Approaches to Pattern Recognition"</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">B.S. in Computer Engineering</h3>
                  <p className="text-muted-foreground">University of California, Berkeley | 1999 - 2003</p>
                </CardHeader>
                <CardContent className="pt-6">
                  <p>Minor in Cognitive Science</p>
                  <p className="mt-2">Graduated Summa Cum Laude, GPA: 3.95/4.0</p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="experience" className="space-y-4">
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">Professor of Computer Science</h3>
                  <p className="text-muted-foreground">University of Excellence | 2018 - Present</p>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Direct the Artificial Intelligence and Human-Computer Interaction Research Lab</li>
                    <li>Lead a team of 10 PhD students and 5 postdoctoral researchers</li>
                    <li>Teach advanced courses in machine learning and computational neuroscience</li>
                    <li>Secured over $5 million in research grants</li>
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">Associate Professor</h3>
                  <p className="text-muted-foreground">MIT | 2012 - 2018</p>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Established the Neural Computation Laboratory</li>
                    <li>Developed new curriculum for graduate-level AI courses</li>
                    <li>Collaborated with industry partners on applied machine learning projects</li>
                    <li>Mentored 15 PhD students to successful completion of their degrees</li>
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">Research Scientist</h3>
                  <p className="text-muted-foreground">Google AI | 2009 - 2012</p>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Developed machine learning algorithms for search ranking optimization</li>
                    <li>Contributed to the early development of computer vision systems</li>
                    <li>Published 12 research papers and filed 5 patents</li>
                    <li>Collaborated with interdisciplinary teams across multiple Google divisions</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="awards" className="space-y-4">
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">Academic & Research Awards</h3>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="list-disc pl-5 space-y-2">
                    <li>National Science Foundation Career Award (2020)</li>
                    <li>Best Paper Award, International Conference on Machine Learning (2019)</li>
                    <li>University Excellence in Teaching Award (2017)</li>
                    <li>Young Investigator Award, AI Research Foundation (2015)</li>
                    <li>Outstanding Dissertation Award, ACM Special Interest Group on AI (2010)</li>
                    <li>Google Research Award for Innovation in AI (2011)</li>
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">Fellowships & Grants</h3>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Principal Investigator, National Science Foundation Grant for AI Ethics Research ($2.5M, 2022-2027)</li>
                    <li>Co-Principal Investigator, Department of Defense Research Initiative ($3.2M, 2020-2024)</li>
                    <li>Microsoft Research Faculty Fellowship (2014-2016)</li>
                    <li>Stanford Graduate Fellowship (2005-2009)</li>
                    <li>National Defense Science and Engineering Graduate Fellowship (2003-2005)</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="skills" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="bg-muted/50">
                    <h3 className="text-xl font-bold">Technical Skills</h3>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Machine Learning & Deep Learning (TensorFlow, PyTorch)</li>
                      <li>Computer Vision & Natural Language Processing</li>
                      <li>Reinforcement Learning & Neural Networks</li>
                      <li>High-Performance Computing & Parallel Processing</li>
                      <li>Programming Languages: Python, C++, R, Julia</li>
                      <li>Data Analysis & Visualization</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="bg-muted/50">
                    <h3 className="text-xl font-bold">Professional Skills</h3>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Research Leadership & Team Management</li>
                      <li>Grant Writing & Project Management</li>
                      <li>Teaching & Curriculum Development</li>
                      <li>Scientific Communication & Public Speaking</li>
                      <li>Industry-Academic Collaboration</li>
                      <li>Ethics in AI & Technology Governance</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader className="bg-muted/50">
                  <h3 className="text-xl font-bold">Languages</h3>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="font-medium">English</p>
                      <p className="text-muted-foreground">Native</p>
                    </div>
                    <div>
                      <p className="font-medium">Spanish</p>
                      <p className="text-muted-foreground">Professional Proficiency</p>
                    </div>
                    <div>
                      <p className="font-medium">Mandarin Chinese</p>
                      <p className="text-muted-foreground">Basic Proficiency</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </section>
  );
}